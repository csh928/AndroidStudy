package com.akj.hello;

public class Car {
    // 현재속도
    private  int currnetSpeed = 0;

    // 최고 속도
    private int maxSpeed = 100;

    // 가속도
    private int acceleration = 3;

    // 브레이크 속도
    private int brakeSpeed = 4;

    //생성자
    public Car(int acceleration, int maxSpeed, int brakeSpeed) {
        this.acceleration = acceleration;
        this.maxSpeed = maxSpeed;
        this.brakeSpeed = brakeSpeed;
    }

    //자동차 엑셀을 밟는 메소드
    public void accelerationPedal() {
        // 페달을 밟을때마다 가속도만큼 현재속도를 올린다. 최고속도 이상으로 가속되지는 않는다.
        currnetSpeed = currnetSpeed + acceleration;
        if (currnetSpeed > maxSpeed) {
            currnetSpeed = maxSpeed;
        }
    }

    //자동차 브레이크 페달을 밟는다
    public void brakePedal() {
        //페달을 밟을때마다 현재속도를 줄인다. 브레이크 페달로 속도가 0 이하는 될수 없다.
        currnetSpeed = currnetSpeed - brakeSpeed;
        if (currnetSpeed < 0) {
            currnetSpeed = 0;
        }
    }

    public String getCurrentSpeedText() {
        return "현재속도는 " + this.currnetSpeed + " km/h 입니다";
    }
}
