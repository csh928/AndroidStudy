package com.akj.hello;

public class SportsCar extends Car {
    //선루프
    private boolean isOpenSunRoof = false;

    public SportsCar(int acceleration, int maxSpeed, int brakeSpeed) {
        super(acceleration, maxSpeed, brakeSpeed);
    }

    //선루프 염
    public void openSunRoof() {
        isOpenSunRoof = true;
    }
    //선루프 닫음
    public void closeSunRoof() {
        isOpenSunRoof = false;
    }

    //선루프 정보
    public String getSunRoofInfo() {
        if (isOpenSunRoof) {
            return "선루프를 열었더니 상쾌하다.";
        } else {
            return "선루프는 닫혀있다.";
        }
    }

    @Override
    public String getCurrentSpeedText() {
        return "스포츠카입니다. " + super.getCurrentSpeedText();
    }
}
